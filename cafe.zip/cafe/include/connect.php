<?php 

$con=mysqli_connect('localhost','root','','cup_corner');
if(!$con){
    die(mysqli_error($con));
}

?>