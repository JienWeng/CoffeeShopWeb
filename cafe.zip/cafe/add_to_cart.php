<?php
session_start();

// Assuming you already have some cart logic
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['productId'])) {
    $productId = $data['productId'];
    $increment = $data['increment'] ?? false; // Check if increment flag is set
    
    if (!isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] = 1; // Add new item with quantity 1
    } else if ($increment) {
        $_SESSION['cart'][$productId]++; // Increment the quantity
    }

    echo json_encode(['message' => 'Product added to cart successfully.']);
} else {
    echo json_encode(['message' => 'Product ID is missing.']);
}
?>
