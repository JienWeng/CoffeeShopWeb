<?php
session_start();

include('config.php'); 


if (!isset($_SESSION['userId']) || $_SESSION['userId'] == null) {
    header('Location: login.php');
    exit;
}


//error_log("All session variables: " . print_r($_SESSION, true));


if (!isset($_SESSION['userId'])) {
    error_log("Session userId not set. Redirecting to login.");
    header('Location: login.php');
    exit;
} else {
    error_log("User is logged in with userId=" . $_SESSION['userId']);
}

// Process the checkout
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $total_payment = 0;
    $user_id = $_SESSION['userId']; 
    $shipping_address = $_POST['shipping_address']; 
    $payment_method = $_POST['payment_method']; 
    $date = date('Y-m-d H:i:s'); 

    
    mysqli_begin_transaction($con);

    try {
        
        foreach ($_SESSION['cart'] as $product_id => $quantity) {
           
            $product_query = "SELECT product_price FROM products WHERE product_id = ?";
            $product_stmt = $con->prepare($product_query);
            $product_stmt->bind_param("i", $product_id);
            $product_stmt->execute();
            $product_result = $product_stmt->get_result();
            $product_data = $product_result->fetch_assoc();
            $price_per_unit = $product_data['product_price'];
            $total_payment += $quantity * $price_per_unit;

            
            $stmt = $con->prepare("INSERT INTO order_details (user_id, product_id, quantity, price_per_unit, total_payment, shipping_address, payment_method, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iiidssss", $user_id, $product_id, $quantity, $price_per_unit, $total_payment, $shipping_address, $payment_method, $date);
            $stmt->execute();
            $stmt->close();
        }

        
        mysqli_commit($con);
        echo "Order placed successfully.";
        unset($_SESSION['cart']); 

    } catch (mysqli_sql_exception $exception) {
        mysqli_rollback($con);
        throw $exception;
    }
    
}
?>
